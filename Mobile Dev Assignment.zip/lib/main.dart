import 'package:flutter/material.dart';

import 'package:font_awesome_flutter/font_awesome_flutter.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // Application name
      title: 'Flutter Assignment',
      theme: ThemeData(
          // Application theme data, you can set the colors for the application as
          // you want
          fontFamily: 'LobsterTwo',
          primarySwatch: Colors.brown),
      home: MyHomePage(title: 'Fareedah\'s Closet'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  final String title;
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(
      appBar: AppBar(
          // Here we take the value from the MyHomePage object that was created by
          // the App.build method, and use it to set our appbar title.
          title: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(
          Icons.shopping_cart,
          size: 30,
        ),
        Text(widget.title),
      ])),
      drawer: Drawer(
        child: SideMenu(),
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(FontAwesomeIcons.shoppingBasket),
        backgroundColor: Colors.brown,
        foregroundColor: Colors.white,
        onPressed: () => {print(" clicked")},
      ),
      body: Column(mainAxisSize: MainAxisSize.max, children: <Widget>[
        Container(
          padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: Colors.brown,
                width: 1.0,
              ),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Text('Ties',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              PopupMenuButton(
                onSelected: (value) {
                  print(value);
                },
                itemBuilder: (BuildContext context) {
                  return [
                    PopupMenuItem(
                      value: 'Ties',
                      child: Text('Ties'),
                    ),
                    PopupMenuItem(
                      value: 'Suit',
                      child: Text('Suit'),
                    ),
                  ];
                },
              ),
            ],
          ),
        ),
        Container(
          padding: EdgeInsets.fromLTRB(5, 40, 5, 40),
          child: Row(children: [
            ConstrainedBox(
              constraints: BoxConstraints.expand(height: 150, width: 170),
              child: SizedBox(
                width: 200.0,
                height: 100.0,
                child: FittedBox(
                  fit: BoxFit.contain,
                  child: RotatedBox(
                    quarterTurns: 4,
                    child: Image.network(
                        'https://i.pinimg.com/564x/b3/0a/7f/b30a7f9f4961bea89a08954739912bcc.jpg'),
                  ),
                ), //SizedBox
              ),
            ),
            ConstrainedBox(
              constraints: BoxConstraints.expand(height: 150, width: 170),
              // Center is a layout widget. It takes a single child and positions it
              // in the middle of the parent.
              child: SizedBox(
                width: 200.0,
                height: 100.0,
                child: FittedBox(
                  fit: BoxFit.contain,
                  child: RotatedBox(
                    quarterTurns: 4,
                    child: Image.network(
                        'https://i.pinimg.com/564x/29/86/43/298643ac65f8c05ab7aa676fb4a63f86.jpg'),
                  ),
                ), //SizedBox
              ),
            ),
          ]),
        ),
        Container(
            padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                TextButton(
                  onPressed: () {},
                  child: Container(
                    color: Colors.brown,
                    padding:
                        const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                    child: const Text(
                      'Shop this look',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 13.0,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () {},
                  child: Container(
                    color: Colors.brown,
                    padding:
                        const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                    child: const Text(
                      'Shop this look',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 13.0,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            )),
        // This trailing comma makes auto-formatting nicer for build methods.
      ]),
    );
  }
}

class SideMenu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: <Widget>[
        ListTile(
          title: Text('Home'),
          onTap: () {
            Navigator.of(context).pop();
            Navigator.of(context).pushNamed('/home');
          },
        ),
        ListTile(
          title: Text('Shop Looks'),
          onTap: () {
            Navigator.of(context).pop();
            Navigator.of(context).pushNamed('/shop');
          },
        ),
      ],
    );
  }
}
